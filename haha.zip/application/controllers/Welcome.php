<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->helper('url');
	}

	public function index()
	{
		$data['artikel'] = null;
		$data['info'] = null;
		$data['nf'] = null;
		$data['home'] = true;
		$data['home2'] = null;
		$data['title'] = '';
		$this->load->view('header', $data);
		$this->load->view('home_view', $data);
		$this->load->view('footer');
	}
}
