<?php

echo '<br /><br /><br /><h1 align="center">Welcome User</h1>';
echo '<p align="center"><a href="'.base_url().'private_area/logout">Logout</a></p>';

?>