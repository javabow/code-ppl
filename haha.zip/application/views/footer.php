				</section>
  			</div>
		</div>
		<hr class="my-3 white">
		<div class="row">
			<div class="col-12">
        		<footer class="page-footer font-small">
          			<div class="footer-copyright text-center py-3">© 2019
            			<a href="https://www.javabow.com">JavaBow</a>. Toram Online is ©Asobimo, Inc. All rights reserved. 
          			</div>
        		</footer>
			</div>
		</div>
	</div>
</body>	
</html>