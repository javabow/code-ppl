<?php if($cari) :?>
<?php $keyword = $_GET['cari']; ?>
<center><h3>Hasil pencarian: <span class="text-danger"><?php echo $keyword; ?></span></h3></center>
<hr class="my-3 white">
<div class="row">
<?php
	$count=0;
	foreach ($cari as $content) :
	?>
	<div class="col d-flex justify-content-center pt-4">
		<div class="card text-dark" style="width: 18rem; height: 300px;">
			<a href="<?php echo base_url(); ?>toram/<?php echo $content->type; ?>/<?php echo $content->url; ?>">
	 		<img class="card-img-top img-thumbnail" style="width: 100%; height: 200px;" src="https://www.javabow.com/img/<?php echo $content->image;?>" alt="Card image cap">
	  		<div class="card-body">
	    		<h5 class="card-title"><?php echo $content->judul;?></h5>
	    		</a>
	  		</div>
		</div>
		<br>
	</div>
	<br>
	<br>
<?php endforeach; ?>
</div>
<?php else :?>
	<p>Maaf data yang anda cari tidak dapat ditemukan :)</p>
<?php endif ; ?>