
<!DOCTYPE html>
<html>
<head>
 <title>Complete Login Register system in Codeigniter</title>
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
</head>

<body>
 <div class="container">
  <br />
  <h3 align="center">Complete Login Register system in Codeigniter</h3>
  <br />
  
  <?php

  echo $message;
  
  ?>
  
 </div>
</body>
</html>

