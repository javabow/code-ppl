<?php if ($artikel): ?>
	<?php foreach ($artikel as $judul) {
		$head = $judul[1];
		$head2 = $title;
	} ?>
<?php endif ?>